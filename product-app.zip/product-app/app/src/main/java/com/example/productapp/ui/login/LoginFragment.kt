package com.example.productapp.ui.login

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import com.example.productapp.R
import com.example.productapp.databinding.FragmentLoginBinding
import com.example.productapp.utils.LoginFactory

class LoginFragment : Fragment() {
    private lateinit var binding: FragmentLoginBinding

    private lateinit var viewModel:LoginViewModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentLoginBinding.inflate(inflater,container,false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initialVM()
        routeView()
        super.onViewCreated(view, savedInstanceState)
    }
    private fun initialVM() {
        viewModel = ViewModelProvider(
            this,
            LoginFactory()
        ).get(LoginViewModel::class.java)
    }
    private fun routeView(){ // Authentication yapan fonksiyon
        binding.buttonGiris.setOnClickListener {
            if(!binding.editTextTextPersonName.text.toString().isNullOrEmpty() && !binding.editTextTextPersonName2.text.toString().isNullOrEmpty()){
               viewModel.auth(binding.editTextTextPersonName.text.toString(), binding.editTextTextPersonName2.text.toString()).observe(viewLifecycleOwner, Observer {
                   if(it){
                       Navigation.findNavController(binding.root).navigate(R.id.action_loginFragment_to_userPanelFragment)
                   }
                   else{
                       Toast.makeText(context, "", Toast.LENGTH_SHORT).show()
                   }
               })
            }
        }
    }
}