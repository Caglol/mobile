package com.example.productapp.ui.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.productapp.R
import com.example.productapp.databinding.FragmentPresentationBinding
import com.example.productapp.utils.FavRecyclerAdapter
import com.example.productapp.utils.PresentationAdapter

class PresentationFragment : Fragment() {
    private lateinit var binding: FragmentPresentationBinding
    private lateinit var adapter: PresentationAdapter
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentPresentationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initialRecycler()
        setContent()
        super.onViewCreated(view, savedInstanceState)
    }
    private fun initialRecycler(){ // recyclerview'i hazırlar
        adapter = PresentationAdapter()
        binding.screensSS.layoutManager = LinearLayoutManager(context)
        binding.screensSS.adapter = adapter

    }
    private fun setContent(){ // recyclerview'in content'ini hazırlar ve recyclerview'e verir
        val list = ArrayList<Int>()
        list.add(R.drawable.main_page)
        list.add(R.drawable.register_main)
        list.add(R.drawable.register_request_permission)
        list.add(R.drawable.register_bottom_sheet)
        list.add(R.drawable.register_camera)
        list.add(R.drawable.register_choose_photo)
        list.add(R.drawable.login_main)
        list.add(R.drawable.user_panel)
        list.add(R.drawable.change_password)
        list.add(R.drawable.list)
        list.add(R.drawable.detail)
        list.add(R.drawable.new_price)
        list.add(R.drawable.follow_list)
        list.add(R.drawable.search_list)
        list.add(R.drawable.empty_list_size)
        list.add(R.drawable.add_wrong)
        list.add(R.drawable.add_correct)
        list.add(R.drawable.fav_list)
        adapter.submitList(list)
    }
}