package com.example.productapp.ui.addproduct

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class AddProductViewModel : ViewModel() {

    fun addProduct(model: AddProductModel): MutableLiveData<Boolean> { // ürün ekleme fonksiyonu
        val user =  FirebaseAuth.getInstance().currentUser?.email?.split("@")
        model.productMarketPrice.user = user?.get(0)
        val isSuccess = MutableLiveData<Boolean>()
        val db = FirebaseDatabase.getInstance().getReference("products")
        db.child(model.productName).setValue(model.productName).addOnCompleteListener { task ->
            db.child(model.productName).child("productName").setValue(model.productName)
            db.child(model.productName).child("productPhoto").setValue(model.productPhoto)
            db.child(model.productName).child("minMarketName").setValue(model.productMarketPrice.productMarketName)
            db.child(model.productName).child("minPrice").setValue(model.productMarketPrice.productPrice)
            db.child(model.productName).child("productMarketPrice").setValue(model.productMarketPrice.productMarketName).addOnSuccessListener {
                db.child(model.productName).child("productMarketPrice").child(model.productMarketPrice.productMarketName).setValue(model.productMarketPrice)
            isSuccess.value = true
            }
        }
        return isSuccess
    }
    fun checkIsIn(name:String): MutableLiveData<Boolean> { // Mevcut ürünün var olup olmadığını kontrol etmeye yarar.
        val isSuccess = MutableLiveData<Boolean>()
        val db = FirebaseDatabase.getInstance().getReference("products")
        db.get().addOnSuccessListener {
            for(child in it.children){
                if(child.key.toString().equals(name)){
                    isSuccess.value = true
                }
            }
            if(isSuccess.value != true){
                isSuccess.value = false
            }
        }
        return isSuccess
    }
}