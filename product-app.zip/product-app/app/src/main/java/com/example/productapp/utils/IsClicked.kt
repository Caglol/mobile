package com.example.productapp.utils

import com.example.productapp.ui.searchproduct.SearchItemModel

interface IsClicked {
    fun isFavClicked(data: SearchItemModel)
    fun isItemClicked(data:String)
}