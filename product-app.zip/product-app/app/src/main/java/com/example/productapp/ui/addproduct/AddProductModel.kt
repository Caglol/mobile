package com.example.productapp.ui.addproduct

data class AddProductModel(val productName: String,
                           val productMarketPrice: ProductMarketModel,
                           val productPhoto: String
)