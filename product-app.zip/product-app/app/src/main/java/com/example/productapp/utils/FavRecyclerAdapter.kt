package com.example.productapp.utils

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.productapp.R
import com.example.productapp.ui.searchproduct.FavModel

class FavRecyclerAdapter(
    private val listener: FavIsClicked
) : ListAdapter<FavModel, FavRecyclerAdapter.FragmentHolder>(
    diffCallback
) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FragmentHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.item_fav_product,
            parent,
            false
        )
        return FragmentHolder(itemView)
    }

    override fun onBindViewHolder(holder: FragmentHolder, position: Int) {
        with(getItem(position)) {
            holder.productName.text = this.name
            holder.productMarketName.text = this.marketName
            holder.productPrice.text = this.currentPrice
        }
    }
    inner class FragmentHolder(iv: View) : RecyclerView.ViewHolder(iv) {
        val productName: TextView = itemView.findViewById(R.id.nameTw)
        val productMarketName: TextView = itemView.findViewById(R.id.marketNameTw)
        val productPrice: TextView = itemView.findViewById(R.id.priceTw)
        val favButton: ImageView = itemView.findViewById(R.id.favButton)
        init {
            favButton.
            setOnClickListener {
                listener.
                isFavClicked(
                    getItem(adapterPosition)
                )
            }
            productName.setOnClickListener {
                listener.isItemClicked(getItem(adapterPosition).name)
            }
        }

    }
}

private val diffCallback = object : DiffUtil.ItemCallback<FavModel>() {
    override fun areItemsTheSame(oldItem: FavModel, newItem: FavModel): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(
        oldItem: FavModel,
        newItem: FavModel
    ): Boolean {
        return oldItem == newItem
    }
}