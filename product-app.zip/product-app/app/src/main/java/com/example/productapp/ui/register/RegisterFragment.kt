package com.example.productapp.ui.register

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import com.example.productapp.R
import com.example.productapp.databinding.FragmentRegisterBinding
import com.example.productapp.utils.RegisterFactory
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.io.ByteArrayOutputStream

class RegisterFragment : Fragment() {
    private lateinit var binding: FragmentRegisterBinding
    private lateinit var viewModel:RegisterViewModel
    private val cameraRequest = 1888
    private val IMAGE_REQUEST: Int = 1
    private var uri: String = ""
    private val REQUEST_ID_MULTIPLE_PERMISSIONS = 7
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentRegisterBinding.inflate(inflater,container,false)

        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initialVM()
        initialClickListener()
        super.onViewCreated(view, savedInstanceState)
    }

    private fun initialVM() {
        viewModel = ViewModelProvider(
            this,
            RegisterFactory()
        ).get(RegisterViewModel::class.java)
    }
    private fun initialClickListener(){
        binding.registerButton.setOnClickListener {
            if(!binding.userPassword.text.toString().isNullOrEmpty() && !binding.userMail.text.toString().isNullOrEmpty() && !uri.equals("")){
                addChild()
            }
        }
        binding.userPhoto.setOnClickListener {
            if (checkAndRequestPermissions()) {
                chooseDialogBottomSheet()
            } else {
                requestPermissions()
            }
        }
    }
    private fun checkAndRequestPermissions(): Boolean {
        val camera = ContextCompat.checkSelfPermission(
            activity!!,
            Manifest.permission.CAMERA
        )
        val wtite = ContextCompat.checkSelfPermission(
            activity!!,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
        val read =
            ContextCompat.checkSelfPermission(activity!!, Manifest.permission.READ_EXTERNAL_STORAGE)
        if (wtite != PackageManager.PERMISSION_GRANTED) {
            return false
        }
        if (camera != PackageManager.PERMISSION_GRANTED) {
            return false
        }
        if (read != PackageManager.PERMISSION_GRANTED) {
            return false
        }
        return true

    }

    private fun requestPermissions(): Boolean {
        val listPermissionsNeeded: MutableList<String> = ArrayList()
        listPermissionsNeeded.
        add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        listPermissionsNeeded.
        add(Manifest.permission.CAMERA)
        listPermissionsNeeded.
        add(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(
                activity!!,
                listPermissionsNeeded.toTypedArray(),
                REQUEST_ID_MULTIPLE_PERMISSIONS
            )
            return false
        }
        return true
    }
    private fun chooseDialogBottomSheet(){
        val view = layoutInflater.
        inflate(
            R.layout.dialog_bottom_sheet_add_media_choose_type,
            null
        )
        val dialog = context?.let { it1 ->
            BottomSheetDialog(
                it1,
                R.style.BottomSheetDialogTheme
            )
        }
        val cameraLinear = view.findViewById<LinearLayout>(R.id.kamera)
        val galleryLinear = view.findViewById<LinearLayout>(R.id.galeri)

        cameraLinear.setOnClickListener {
            if(dialog != null){
                takePhoto()
                dialog.dismiss()
            }
        }
        galleryLinear.setOnClickListener {
            if(dialog != null){
                choosePhoto()
                dialog.dismiss()
            }
        }
        if (dialog != null) {
            dialog.setCancelable(true)
        }
        if (dialog != null) {
            dialog.setContentView(view)
        }
        if (dialog != null) {
            dialog.show()
        }
    }
    private fun takePhoto(){
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(cameraIntent, cameraRequest)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == cameraRequest) {
            if (data!=null && data.extras !=null ) {
                if (data.extras!!.get("data") !=null) {
                    val photo: Bitmap = data?.extras?.get("data") as Bitmap
                    binding.userPhoto.setImageBitmap(photo)
                    encodeBitmapAndSave()
                }
            }
        }
        if (requestCode == IMAGE_REQUEST) {
            if (data?.data != null) {
                 binding.userPhoto.setImageURI(data.data)
                encodeBitmapAndSave()
            }
        }
    }
    private fun choosePhoto() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(
            intent,
            IMAGE_REQUEST
        )
    }
    private fun encodeBitmapAndSave() {
        binding.userPhoto.isDrawingCacheEnabled = true
        binding.userPhoto.buildDrawingCache()
        val bitmap = (binding.userPhoto.drawable as Drawable).toBitmap()
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
        uri= Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT)
    }
    private fun addChild(){ // yukarıdaki bilgilerin hepsi tamamsa kaydı gerçekleştirmek için viewmodel'e aktarır
            viewModel.register(binding.userMail.text.toString(), binding.userPassword.text.toString()).observe(viewLifecycleOwner, Observer {
                viewModel.registerInDb(RegisterModel(binding.userMail.text.toString(), uri)).observe(viewLifecycleOwner, Observer {
                    if(it){
                        showToast("Kaydınız başarı ile gerçekleştirilmiştir!")
                        Navigation.findNavController(binding.root).navigate(R.id.action_registerFragment_to_loginFragment)
                    }
                })
            })

    }
    private fun showToast(message: String){ // hata ve başarı mesajlarını yazar
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

}