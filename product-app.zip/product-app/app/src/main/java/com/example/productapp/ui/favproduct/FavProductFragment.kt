package com.example.productapp.ui.favproduct

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.productapp.R
import com.example.productapp.databinding.FragmentFavProductBinding
import com.example.productapp.ui.searchproduct.FavModel
import com.example.productapp.utils.*

class FavProductFragment : Fragment(), FavIsClicked {
    private lateinit var binding: FragmentFavProductBinding
    private lateinit var viewModel:FavProductViewModel
    private lateinit var adapter: FavRecyclerAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentFavProductBinding.inflate(inflater,container,false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initialVM()
        initialRecycler()
        getItems()
        super.onViewCreated(view, savedInstanceState)
    }
    private fun initialVM() {
        viewModel = ViewModelProvider(
            this,
            FavFactory(context!!)
        ).get(FavProductViewModel::class.java)
    }
    private fun initialRecycler(){ // recyclerview'i hazırlar
        adapter = FavRecyclerAdapter(this)
        binding.favRecycler.layoutManager = LinearLayoutManager(context)
        binding.favRecycler.adapter = adapter
    }
    private fun getItems(){ // room database'de bulunan tüm bilgileri çekip recyclerview'e yazar
        viewModel.getAllProducts().observe(viewLifecycleOwner, Observer {
            adapter.submitList(it)
        })
    }

    override fun isFavClicked(data: FavModel) { // recyclerview'de clicklenen itemi siler
        viewModel.deleteToDb(FavModel(data.name, data.currentPrice, data.marketName))
        getItems()
    }

    override fun isItemClicked(data: String) { // clicklenen itemin detay sayfasını açar
        val bundle = Bundle()
        bundle.putString("data", data)
        Navigation.findNavController(binding.root).navigate(R.id.action_favProductFragment_to_productDetailFragment, bundle)
    }
}