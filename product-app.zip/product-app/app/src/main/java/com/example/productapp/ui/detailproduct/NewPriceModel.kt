package com.example.productapp.ui.detailproduct

import com.example.productapp.ui.addproduct.ProductMarketModel

data class NewPriceModel(val productName: String,
                           val productMarketPrice: ProductMarketModel )