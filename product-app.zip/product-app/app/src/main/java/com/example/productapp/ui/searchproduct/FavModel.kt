package com.example.productapp.ui.searchproduct

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity
data class FavModel(
    @PrimaryKey
    var name: String,
    var currentPrice: String,
    var marketName: String
) : Serializable