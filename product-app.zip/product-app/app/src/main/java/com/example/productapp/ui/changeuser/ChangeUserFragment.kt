package com.example.productapp.ui.changeuser

import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import com.bumptech.glide.Glide
import com.example.productapp.R
import com.example.productapp.databinding.FragmentChangeUserBinding
import com.example.productapp.utils.ChangeFactory

class ChangeUserFragment : Fragment() {
    private lateinit var binding: FragmentChangeUserBinding
    private lateinit var viewModel:ChangeUserViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentChangeUserBinding.inflate(inflater,container,false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initialVM()
        checkUser()
        changePassword()
        deleteAccount()
        super.onViewCreated(view, savedInstanceState)
    }

    private fun initialVM() {
        viewModel = ViewModelProvider(
            this,
            ChangeFactory()
        ).get(ChangeUserViewModel::class.java)

    }
    private fun checkUser(){ // User'ın bilglierini getirir ve ekrana basar.
        viewModel.checkDetails().observe(viewLifecycleOwner, Observer {
            if(it.userPhoto.equals("null")){
                context?.let { it1 -> Glide.with(it1).load(R.drawable.ic_launcher_background).into(binding.userPhoto) }
            }
            else {
                val decodedByteArray: ByteArray = Base64.decode(
                    it.userPhoto,
                    Base64.DEFAULT
                )
                binding.userPhoto.setImageBitmap(
                    BitmapFactory.decodeByteArray(
                        decodedByteArray,
                        0,
                        decodedByteArray.size
                    )
                )
            }

            binding.userEmail.text = it.userMail
        })
    }
    private fun deleteAccount(){ // user eğer ki silinmesi isteniyorsa siler
        binding.deleteAccount.setOnClickListener {
            viewModel.deleteAccountRTDB().observe(viewLifecycleOwner, Observer {
                if(it){
                    viewModel.deleteAccount().observe(viewLifecycleOwner, Observer {
                        if(it){
                            showToast("Silme işlemi başarılı. Ana sayfaya yönlendiriliyorsunuz.")
                            Navigation.findNavController(binding.root).navigate(R.id.action_changeUserFragment_to_loginFragment)
                        }
                    })
                }else{
                    showToast("Silme işlemi başarısız!")
                }
            })
        }
    }
    private fun changePassword(){ // şifre değiştirme fonksiyonu
        binding.changeButton.setOnClickListener {
            if(binding.password.text.toString().trim().length>=6){
                viewModel.changePassword(binding.password.text.toString().trim()).observe(viewLifecycleOwner, Observer {
                    if(it){
                        showToast("Şifreniz değiştirildi!")
                        binding.password.text.clear()
                    }else{
                        showToast("Şifre değiştirilemedi lütfen kontrol edin!")
                    }
                })
            }
        }
    }
    private fun showToast(message:String){ // hata mesajları için fonksiyon
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}