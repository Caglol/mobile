package com.example.productapp.ui.searchproduct

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface FavDAO {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(fav: FavModel)

    @Delete
    fun delete(fav: FavModel)

    @Query("select * from favmodel order by name desc")
    fun getAllGames(): LiveData<List<FavModel>>
}