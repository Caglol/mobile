package com.example.productapp.ui.searchproduct

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.database.FirebaseDatabase

class SearchProductViewModel(context: Context): ViewModel() {
    private val repository = FavRepository(context )
    private val getallGames = repository.getAllGames()

    fun getItems(): MutableLiveData<List<SearchItemModel>>{
        val list = arrayListOf<SearchItemModel>()
        val returnList = MutableLiveData<List<SearchItemModel>>()
        val db = FirebaseDatabase.getInstance().getReference("products")
        db.get().addOnSuccessListener {
            for(child in it.children){
                list.add(SearchItemModel(child.key.toString(), child.child("minPrice").getValue().toString(), child.child("minMarketName").getValue().toString(),false))
            }
            returnList.value = list
        }
        return returnList
    }
    fun searchItem(name:String): MutableLiveData<List<SearchItemModel>> {
        val list = arrayListOf<SearchItemModel>()
        val returnList = MutableLiveData<List<SearchItemModel>>()
        val db = FirebaseDatabase.getInstance().getReference("products")
        db.get().addOnSuccessListener {
            for(child in it.children){
                if(child.key.toString().contains(name)){
                    list.add(SearchItemModel(child.key.toString(), child.child("minPrice").getValue().toString(), child.child("minMarketName").getValue().toString(),false))
                }
            }
            returnList.value = list
        }
        return returnList
    }
    fun insertToDb(name:String, currentPrice: String, marketName:String){
        Log.d("TAG", "insertToDb: " + name)
        repository.insert(FavModel(name, currentPrice, marketName))
    }
    fun deleteToDb(name:String,currentPrice:String, marketName: String){
        repository.delete(FavModel(name, currentPrice, marketName))
    }
    fun getAllProducts(): LiveData<List<FavModel>> {
        return repository.getAllGames()
    }
}