package com.example.productapp.utils

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.productapp.ui.changeuser.ChangeUserViewModel

class ChangeFactory() :
    ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return ChangeUserViewModel() as T
    }
}