package com.example.productapp.ui.searchproduct

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.productapp.R
import com.example.productapp.databinding.FragmentSearchProductBinding
import com.example.productapp.utils.IsClicked
import com.example.productapp.utils.SearchAdapter
import com.example.productapp.utils.SearchFactory
import kotlinx.coroutines.runBlocking

class SearchProductFragment : Fragment(), IsClicked {
    private lateinit var binding: FragmentSearchProductBinding
    private lateinit var viewModel:SearchProductViewModel
    private lateinit var adapter: SearchAdapter
    private lateinit var roomList: List<FavModel>
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentSearchProductBinding.inflate(inflater,container,false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initialVM()
        initialRecyclerview()
        getItems()
        initialTextWatcher()
        initialClickListener()
        super.onViewCreated(view, savedInstanceState)
    }
    private fun initialRecyclerview(){ // recyclerview'i hazırlar
        adapter = SearchAdapter(this)
        binding.searchProductFragmentRecycler.layoutManager = LinearLayoutManager(context)
        binding.searchProductFragmentRecycler.adapter = adapter
    }
    private fun initialTextWatcher(){ // edittext'in textwatcher özelliğini başlatır
        binding.editTextTextPersonName3.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
               if(p0 != null){
                   if(p0.length >= 3){
                       getSearchedItem(p0.toString())
                   }
                   if(p0.length < 2){
                       getItems()
                   }
               }
            }
            override fun afterTextChanged(p0: Editable?) {}
        })
    }
    private fun getSearchedItem(item:String){ // aranan itemin getirilmesini sağlar
        viewModel.searchItem(item).observe(viewLifecycleOwner, Observer { fb->
            viewModel.getAllProducts().observe(viewLifecycleOwner, Observer { db->
                roomList = db
                if(db.size != 0){

                    for (i in 0..fb.size-1){
                        for(t in 0..db.size-1){
                            if(fb.get(i).name.equals(db.get(t).name)){
                                fb.get(i).isFav = true
                            }
                        }
                    }
                }
                if(fb.size == 0){
                    binding.goAddFragment.visibility = View.VISIBLE
                } else{
                    binding.goAddFragment.visibility = View.INVISIBLE
                }
                adapter.submitList(fb)
            })
        })
    }
    private fun getItems(){ // tüm itemleri realtime database'den getirir
        viewModel.getItems().observe(viewLifecycleOwner, Observer { fb->
                viewModel.getAllProducts().observe(viewLifecycleOwner, Observer { db->
                    roomList = db
                    if(db.size != 0){
                        for (i in 0..fb.size-1){
                            for(t in 0..db.size-1){
                                if(fb.get(i).name.equals(db.get(t).name)){
                                    fb.get(i).isFav = true
                                }
                            }
                        }
                    }
                    if(fb.size == 0){
                        binding.goAddFragment.visibility = View.VISIBLE
                    } else{
                        binding.goAddFragment.visibility = View.INVISIBLE
                    }
                    adapter.submitList(fb)
                })

        })
    }
    private fun initialClickListener(){
        binding.goAddFragment.setOnClickListener {
            Navigation.findNavController(binding.root).navigate(R.id.action_searchProductFragment_to_addProductFragment)
        }
    }
    private fun initialVM() {
        viewModel = ViewModelProvider(
            this,
            SearchFactory( context!!)
        ).get(SearchProductViewModel::class.java)
    }

    override fun isFavClicked(data: SearchItemModel) { // recycler view'den tıklanan itemi database'de siler veya ekler
        if(data.isFav == true){
            runBlocking {
                viewModel.deleteToDb(data.name, data.currentPrice, data.marketName)
                getItems()
                if(!binding.editTextTextPersonName3.text.toString().isNullOrEmpty()){
                    binding.editTextTextPersonName3.text.clear()
                }
            }
        } else{
            runBlocking {
                viewModel.insertToDb(data.name, data.currentPrice, data.marketName)
                getItems()
                if(!binding.editTextTextPersonName3.text.toString().isNullOrEmpty()){
                    binding.editTextTextPersonName3.text.clear()
                }
            }
        }
    }

    override fun isItemClicked(data: String) { // recyclerview'deki tıklanan itemin detay sayfasına aktarımını sağlar
        val bundle = Bundle()
        bundle.putString("data", data)
        Navigation.findNavController(binding.root).navigate(R.id.action_searchProductFragment_to_productDetailFragment, bundle)
    }
}