package com.example.productapp.ui.detailproduct

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.productapp.ui.addproduct.ProductMarketModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class ProductDetailViewModel : ViewModel() {
    fun addNewPrice(newPriceModel: NewPriceModel){ // yeni fiyat girişi yapar
        newPriceModel.productMarketPrice.user = FirebaseAuth.getInstance().currentUser?.email?.split("@")?.get(0)
        val db = FirebaseDatabase.getInstance().getReference("products")
        db.child(newPriceModel.productName)
            .child("productMarketPrice")
            .child(newPriceModel.productMarketPrice.productMarketName)
            .setValue(newPriceModel.productMarketPrice)
    }
    fun setMinPrice(productName: String, marketName: String, newPrice:String){ // yeni fiyat girişinde minimum değerden küçük bir değer girilirse relatime database'den minmum değeri tekrar setler
        val db = FirebaseDatabase.getInstance().getReference("products")
        db.child(productName).child("minMarketName").setValue(marketName)
        db.child(productName).child("minPrice").setValue(newPrice)
    }
    fun checkDetail(data: String): MutableLiveData<DetailModel>{ // tıklanıp girilen ürünün detaylarını getirir
        val model = MutableLiveData<DetailModel>()
        val db = FirebaseDatabase.getInstance().getReference("products")
        db.child(data).get().addOnSuccessListener {
            val productName =it.child("productName").getValue().toString()
            val productPhoto =  it.child("productPhoto").getValue().toString()
            val productMarketModel = ArrayList<ProductMarketModel>()
            db.child(data).child("productMarketPrice").get().addOnSuccessListener {
                for (child in it.children) {
                    productMarketModel.add(
                        ProductMarketModel(
                            child.child("productMarketName").getValue().toString(),
                            child.child("productPrice").getValue().toString(),
                            child.child("productDate").getValue().toString(),
                            child.child("user").getValue().toString()
                        )
                    )
                }
                val modelx = DetailModel(productName , productPhoto, productMarketModel)
                model.value = modelx
            }
        }
        return model
    }
}