package com.example.productapp.utils

import com.example.productapp.ui.searchproduct.FavModel

interface FavIsClicked {
    fun isFavClicked(data: FavModel)
    fun isItemClicked(data:String)
}