package com.example.productapp.ui.searchproduct

import android.content.Context
import androidx.lifecycle.LiveData
import com.example.productapp.utils.subscribeOnBackground

class FavRepository(context: Context) {

    private var favDao: FavDAO
    private var allGames: LiveData<List<FavModel>>

    private val database = FavDataBase.getInstance(context)

    init {
        favDao = database.favDao()
        allGames = favDao.getAllGames()
    }

    fun insert(fav: FavModel) { // database'e ekleme fonksiyonu
        subscribeOnBackground {
            favDao.insert(fav)
        }
    }

    fun delete(fav: FavModel) { // database'den sime fonksiyonu
        subscribeOnBackground {
            favDao.delete(fav)
        }
    }

    fun getAllGames(): LiveData<List<FavModel>> {
        return allGames
    }
}