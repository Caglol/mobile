package com.example.productapp.ui.register

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class RegisterViewModel : ViewModel() {
    fun register(mail: String, password: String): MutableLiveData<Boolean> { // user'ı authentication'a ekler
        val firebaseAuth = FirebaseAuth.getInstance()
        val isSuccess = MutableLiveData<Boolean>()
        firebaseAuth.createUserWithEmailAndPassword(mail, password)
            .addOnCompleteListener {
                if (it.isSuccessful) {
                    isSuccess.value = it.isSuccessful

                } else {
                    isSuccess.value = false
                }
            }
        return isSuccess
    }
    fun registerInDb(model: RegisterModel): MutableLiveData<Boolean>{ // user'ı realtime database'e ekler
        val isSuccess = MutableLiveData<Boolean>()
        val key = model.email.split("@")
        val db = FirebaseDatabase.getInstance().getReference("users")
        db.child(key.get(0)).setValue(model).addOnCompleteListener { task ->
            isSuccess.value = task.isSuccessful
        }
            return isSuccess
        }

}