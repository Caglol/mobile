package com.example.productapp.utils

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.productapp.R
import com.example.productapp.ui.searchproduct.FavModel

class PresentationAdapter(
) : ListAdapter<Int, PresentationAdapter.FragmentHolder>(
    diffCallback
) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FragmentHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.item_presentation,
            parent,
            false
        )
        return FragmentHolder(itemView)
    }

    override fun onBindViewHolder(holder: FragmentHolder, position: Int) {
        with(getItem(position)) {
            holder.presentationItem.setBackgroundResource(this)
        }
    }
    inner class FragmentHolder(iv: View) : RecyclerView.ViewHolder(iv) {
        val presentationItem: ImageView = itemView.findViewById(R.id.imageView)
    }
}

private val diffCallback = object : DiffUtil.ItemCallback<Int>() {
    override fun areItemsTheSame(oldItem: Int, newItem: Int): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(
        oldItem: Int,
        newItem: Int
    ): Boolean {
        return oldItem == newItem
    }
}