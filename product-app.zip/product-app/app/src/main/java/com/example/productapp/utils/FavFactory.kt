package com.example.productapp.utils

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.productapp.ui.favproduct.FavProductViewModel

class FavFactory( val context: Context) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return FavProductViewModel(context) as T
    }
}