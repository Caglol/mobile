package com.example.productapp.ui.addproduct

data class ProductMarketModel(val productMarketName:String ,
                              val productPrice:String,
                              val productDate: String, var user: String?)