package com.example.productapp.ui.detailproduct

import com.example.productapp.ui.addproduct.ProductMarketModel

data class DetailModel(val productName: String, val productPhoto: String, val priceList: List<ProductMarketModel>)