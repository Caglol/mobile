package com.example.productapp.utils

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.productapp.R
import com.example.productapp.ui.addproduct.ProductMarketModel

class DetailProductAdapter(
) : ListAdapter<ProductMarketModel, DetailProductAdapter.FragmentHolder>(
    diffCallback
) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FragmentHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.item_detail_product,
            parent,
            false
        )
        return FragmentHolder(itemView)
    }

    override fun onBindViewHolder(holder: FragmentHolder, position: Int) {
        with(getItem(position)) {
            holder.detailProductDate.text = this.productDate
            holder.detailProductUserName.text = this.user
            holder.detailProductMarketName.text = this.productMarketName
            holder.detailProductPriceInfo.text = this.productPrice
                Log.d("TAG", "onBindViewHolder: " + this.productMarketName)
        }
    }
    inner class FragmentHolder(iv: View) : RecyclerView.ViewHolder(iv) {
        val detailProductUserName: TextView = iv.findViewById(R.id.itemDetailUserName)
        val detailProductDate: TextView = iv.findViewById(R.id.itemDetailProductDate)
        val detailProductMarketName: TextView = iv.findViewById(R.id.itemDetailMarketName)
        val detailProductPriceInfo: TextView = iv.findViewById(R.id.itemDetailPriceInfo)

    }
}

private val diffCallback = object : DiffUtil.ItemCallback<ProductMarketModel>() {
    override fun areItemsTheSame(oldItem: ProductMarketModel, newItem: ProductMarketModel): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(
        oldItem: ProductMarketModel,
        newItem: ProductMarketModel
    ): Boolean {
        return oldItem == newItem
    }
}