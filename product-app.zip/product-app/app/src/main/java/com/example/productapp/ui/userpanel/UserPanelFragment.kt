package com.example.productapp.ui.userpanel

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.productapp.R
import com.example.productapp.databinding.FragmentUserPanelBinding

class UserPanelFragment : Fragment() {
    private lateinit var binding: FragmentUserPanelBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentUserPanelBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        routeView()
        super.onViewCreated(view, savedInstanceState)
    }
    private fun checkDB(){

    }
    private fun routeView(){
        binding.button.setOnClickListener {
            Navigation.findNavController(binding.root).navigate(R.id.action_userPanelFragment_to_changeUserFragment)
        }
        binding.button2.setOnClickListener {
            Navigation.findNavController(binding.root).navigate(R.id.action_userPanelFragment_to_searchProductFragment2)

        }
        binding.button3.setOnClickListener {
            Navigation.findNavController(binding.root).navigate(R.id.action_userPanelFragment_to_addProductFragment)

        }
        binding.button4.setOnClickListener {
            Navigation.findNavController(binding.root).navigate(R.id.action_userPanelFragment_to_favProductFragment)

        }
    }
}