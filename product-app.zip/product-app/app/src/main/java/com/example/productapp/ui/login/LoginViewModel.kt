package com.example.productapp.ui.login

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth

class LoginViewModel : ViewModel() {
    fun auth(email:String, password: String): MutableLiveData<Boolean>{ // firebase authentication'u yapan fonksiyon
        val authFirebase = FirebaseAuth.getInstance()
        val isSuccess = MutableLiveData<Boolean>()
        authFirebase.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                isSuccess.value = (task.isSuccessful)
            }.addOnFailureListener{
                isSuccess.value = false
            }
        return isSuccess
    }
}