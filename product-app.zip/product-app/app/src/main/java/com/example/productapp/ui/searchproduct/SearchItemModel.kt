package com.example.productapp.ui.searchproduct

data class SearchItemModel(val name:String, var currentPrice: String, var marketName: String, var isFav: Boolean)