package com.example.productapp.ui.changeuser

data class UserModel(val userMail: String, val userPhoto: String)