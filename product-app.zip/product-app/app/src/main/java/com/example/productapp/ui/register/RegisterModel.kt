package com.example.productapp.ui.register

data class RegisterModel(val email: String,  val photo: String)