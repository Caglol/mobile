package com.example.productapp.ui.detailproduct

import android.app.AlertDialog
import android.content.DialogInterface
import android.graphics.BitmapFactory
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.productapp.databinding.FragmentProductDetailBinding
import com.example.productapp.ui.addproduct.ProductMarketModel
import com.example.productapp.utils.DetailFactory
import com.example.productapp.utils.DetailProductAdapter

class ProductDetailFragment : Fragment() {
    private lateinit var binding: FragmentProductDetailBinding
    private lateinit var viewModel:ProductDetailViewModel
    private lateinit var adapter: DetailProductAdapter
    private lateinit var dataList: List<ProductMarketModel>
    private var priceSortMinMax = false
    private var dateMinMax = false
    private var userNameMinMax = false
    private var marketNameMinMax = false
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentProductDetailBinding.inflate(inflater,container,false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        dataList = listOf()
        initialVM()
        initialRecycler()
        checkProductDetails()
        initialClickListeners()
        super.onViewCreated(view, savedInstanceState)
    }
    private fun initialVM() {
        viewModel = ViewModelProvider(
            this,
            DetailFactory()
        ).get(ProductDetailViewModel::class.java)
    }
    private fun initialClickListeners(){ // click listener'ların tanımlandığı fonksiyon
        binding.newPrice.setOnClickListener {
            newPrice()
        }
            binding.priceTw.setOnClickListener {
                var newList = listOf<ProductMarketModel>()
                if(!priceSortMinMax){
                   newList = dataList.sortedBy { it.productPrice }
                    priceSortMinMax = true
                } else {
                    newList = dataList.sortedByDescending { it.productPrice }
                    priceSortMinMax = false
                }

                initialRecycler()
                adapter.submitList(newList)
            }
            binding.dateTw.setOnClickListener {
                var newList = listOf<ProductMarketModel>()
                if(!dateMinMax){
                    newList = dataList.sortedBy { it.productDate }
                    dateMinMax = true
                } else {
                    newList = dataList.sortedByDescending { it.productDate }
                    dateMinMax = false
                }

                initialRecycler()
                adapter.submitList(newList)
            }
            binding.userNameTw.setOnClickListener {
                var newList = listOf<ProductMarketModel>()
                if(!userNameMinMax){
                    newList = dataList.sortedBy { it.user }
                    userNameMinMax = true
                } else {
                    newList = dataList.sortedByDescending { it.user }
                    userNameMinMax = false
                }

                initialRecycler()
                adapter.submitList(newList)
            }
            binding.marketTw.setOnClickListener {
                var newList = listOf<ProductMarketModel>()
                if(!marketNameMinMax){
                    newList = dataList.sortedBy { it.productMarketName }
                    marketNameMinMax = true
                } else {
                    newList = dataList.sortedByDescending { it.productMarketName }
                    marketNameMinMax = false
                }

                initialRecycler()
                adapter.submitList(newList)
        }
    }
    private fun newPrice(){ // yeni bir değer girilecekse. Bu fonksiyon tetiklenir
        val alert =  AlertDialog.Builder(context!!)
        val marketName = EditText(context!!)
        marketName.hint = "Market İsmi"
        marketName.maxLines = 1
        val newPrice = EditText(context!!)
        newPrice.inputType = InputType.TYPE_CLASS_NUMBER
        newPrice.hint = "Fiyat"
        newPrice.maxLines = 1
        val date = EditText(context!!)
        date.inputType = InputType.TYPE_CLASS_DATETIME
        date.hint = "Tarih"
        date.maxLines = 1
        val layout = LinearLayout(context!!)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPaddingRelative(45,15,45,0)
        alert.setTitle("Yeni Fiyat Girişi")
        layout.addView(marketName)
        layout.addView(newPrice)
        layout.addView(date)
        alert.setView(layout)
        alert.setPositiveButton("Tamam", DialogInterface.OnClickListener {
                dialog, which ->
            run {
                val marketName = marketName.text.toString()
                val date = date.text.toString()
                val newPrice = newPrice.text.toString()
                if(!marketName.isNullOrEmpty() && !date.isNullOrEmpty() && !newPrice.isNullOrEmpty()){
                    addNewPrice(marketName,newPrice, date)
                    compareNewPrice(newPrice,marketName)
                }
            }
        })
        alert.setNegativeButton("İptal", DialogInterface.OnClickListener {
                dialog, which ->
            run {
                dialog.dismiss()
            }
        })
        alert.show()
    }
    private fun checkProductDetails(){ // ürünün detaylarını getirir
        val item = arguments?.getString("data")
        viewModel.checkDetail(item.toString()).observe(viewLifecycleOwner, Observer {
            binding.detailProductName.text = it.productName
            val decodedByteArray: ByteArray = Base64.decode(
                it.productPhoto,
                Base64.DEFAULT
            )
            binding.detailProductPhoto.setImageBitmap(
                BitmapFactory.decodeByteArray(
                    decodedByteArray,
                    0,
                    decodedByteArray.size
                )
            )
            dataList = it.priceList
            initialRecycler()
            adapter.submitList(it.priceList)
        })
    }
    private fun addNewPrice(marketName: String, newPrice:String, date:String){ // alert dialogtan bilgileri alıp viewmodele yollar
        viewModel.addNewPrice(NewPriceModel(arguments?.get("data").toString(), ProductMarketModel(marketName, newPrice, date, "")))
        checkProductDetails()

    }
    private fun initialRecycler(){ // recyclerview'i hazırlar
            adapter = DetailProductAdapter()
            binding.detailProductPriceHistoryRecycler.layoutManager = LinearLayoutManager(context)
            binding.detailProductPriceHistoryRecycler.adapter = adapter
    }
    private fun compareNewPrice(newPrice: String, marketName: String){ // min max değer kontrolü yapar. Eğer ki yeni girilen değer küçükse realtime databaseden yeni minimum değeri set eder.
        val newPriceInt = newPrice.toInt()
        dataList.size
        if(dataList.size>0){
            var min = dataList.get(0).productPrice.toInt()
            for(i in 1..dataList.size-1){
                if(dataList.get(i).productPrice.toInt()<min){
                    min = dataList.get(i).productPrice.toInt()
                }
            }
            if(min > newPriceInt){
                viewModel.setMinPrice(arguments?.get("data").toString(),marketName,newPrice)
            }
        }
    }
}