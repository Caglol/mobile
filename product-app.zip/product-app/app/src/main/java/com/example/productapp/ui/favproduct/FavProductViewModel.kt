package com.example.productapp.ui.favproduct

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.productapp.ui.searchproduct.FavModel
import com.example.productapp.ui.searchproduct.FavRepository

class FavProductViewModel(context: Context): ViewModel() {
    private val repository = FavRepository(context )
    fun deleteToDb(model: FavModel){ // room'db den siler
        repository.delete(model)
    }
    fun getAllProducts(): LiveData<List<FavModel>> { // room db'den tüm değerleri getirir
        return repository.getAllGames()
    }

}