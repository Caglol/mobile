package com.example.productapp.utils

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.productapp.R
import com.example.productapp.ui.searchproduct.SearchItemModel

class SearchAdapter(
    private val listener: IsClicked
) : ListAdapter<SearchItemModel, SearchAdapter.FragmentHolder>(
    diffCallback
) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FragmentHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.item_search_recycler,
            parent,
            false
        )
        return FragmentHolder(itemView)
    }

    override fun onBindViewHolder(holder: FragmentHolder, position: Int) {
        with(getItem(position)) {
            holder.productName.text = this.name
            checkFav(imageView = holder.favButton, flag = this.isFav)
        }
    }
    private fun checkFav(imageView: ImageView, flag:Boolean){
        Log.d("TAG", "checkFav: " + flag)
        if(flag){
            imageView.setBackgroundResource(R.drawable.ic_fav)
        } else{
            imageView.setBackgroundResource(R.drawable.ic_unfav)
        }
    }
    inner class FragmentHolder(iv: View) : RecyclerView.ViewHolder(iv) {
        val productName: TextView = itemView.findViewById(R.id.productNameRecyclerItem)
        val favButton: ImageView = itemView.findViewById(R.id.favButton)
        init {
            favButton.
            setOnClickListener {
                listener.
                isFavClicked(
                    getItem(adapterPosition)
                )
                getItem(adapterPosition).isFav = !getItem(adapterPosition).isFav
                checkFav(favButton, getItem(adapterPosition).isFav)
            }
            productName.setOnClickListener {
                listener.isItemClicked(getItem(adapterPosition).name)
            }
        }

    }
}

private val diffCallback = object : DiffUtil.ItemCallback<SearchItemModel>() {
    override fun areItemsTheSame(oldItem: SearchItemModel, newItem: SearchItemModel): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(
        oldItem: SearchItemModel,
        newItem: SearchItemModel
    ): Boolean {
        return oldItem == newItem
    }
}