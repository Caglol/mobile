package com.example.productapp.ui.changeuser

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class ChangeUserViewModel: ViewModel() {
    fun deleteAccount(): MutableLiveData<Boolean>{ // hesap silme fonksiyonu
        val isSuccess = MutableLiveData<Boolean>()
        FirebaseAuth.getInstance().currentUser?.delete()?.addOnCompleteListener {
            isSuccess.value = it.isSuccessful
        }
        return isSuccess
    }
    fun deleteAccountRTDB(): MutableLiveData<Boolean>{ // silinen hesabı Real time database'den silen fonksiyon
        val user = FirebaseAuth.getInstance().currentUser?.email
        val isSuccess = MutableLiveData<Boolean>()
        val db = FirebaseDatabase.getInstance().getReference("users")
        db.child(user?.split("@")?.get(0).toString()).removeValue().addOnCompleteListener {
            isSuccess.value = it.isSuccessful
        }
        return isSuccess
    }
    fun changePassword(password: String): MutableLiveData<Boolean>{ // şifreyi değiştiren fonksiyon
        val isSuccess = MutableLiveData<Boolean>()
        val user = FirebaseAuth.getInstance().currentUser

        user!!.updatePassword(password).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                isSuccess.value = task.isSuccessful
                println("Update Success")
            } else {
                isSuccess.value = task.isSuccessful
                println("Erorr Update")
            }
        }
        return isSuccess
    }
    fun checkDetails(): MutableLiveData<UserModel>{ // detayları realtime database'den alan fonksiyon
        val userDetail = MutableLiveData<UserModel>()
        val user = FirebaseAuth.getInstance().currentUser?.email
        val userSplit = user?.split("@")
        val db = FirebaseDatabase.getInstance().getReference("users")
        db.get().addOnSuccessListener {
            for(child in it.children){
                if(child.key.toString().equals(userSplit?.get(0))){
                    userDetail.value = UserModel(child.child("email").getValue().toString(),
                        child.child("photo").getValue().toString())
                }
            }
        }
        return userDetail
    }
}