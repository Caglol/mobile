package com.example.productapp.ui.preview

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.productapp.R
import com.example.productapp.databinding.FragmentPreviewBinding

class PreviewFragment : Fragment() {
    private lateinit var binding: FragmentPreviewBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentPreviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        clickListener()
        super.onViewCreated(view, savedInstanceState)
    }
    private fun clickListener(){ // butonların click listenerlerini hazırlar
        binding.login.setOnClickListener {
            Navigation.findNavController(binding.root).navigate(R.id.action_previewFragment2_to_loginFragment)
        }
        binding.presentation.setOnClickListener {
            Navigation.findNavController(binding.root).navigate(R.id.action_previewFragment2_to_presentationFragment)

        }
        binding.register.setOnClickListener {
            Navigation.findNavController(binding.root).navigate(R.id.action_previewFragment2_to_registerFragment)
        }
    }
}